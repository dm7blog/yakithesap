package com.dm7blog.yakithesap1

import android.annotation.SuppressLint
import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import kotlin.text.*

class MainActivity : AppCompatActivity() {

    private lateinit var editor: SharedPreferences.Editor
    private lateinit var sprefs: SharedPreferences
    private lateinit var vkm: EditText
    private lateinit var kkm: EditText
    private lateinit var ort: EditText
    private lateinit var fiyat: EditText
    private lateinit var surum: TextView
    private lateinit var ykm: TextView
    private lateinit var kmyakilan: TextView
    private lateinit var hrcm: TextView
    private lateinit var bthesapla: Button
    private lateinit var bttemizle: Button

    @SuppressLint("CommitPrefEdits")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        vkm = findViewById(R.id.etVariskm)
        kkm = findViewById(R.id.etKalkiskm)
        ort = findViewById(R.id.etOrtalama)
        fiyat = findViewById(R.id.etFiyat)
        ykm = findViewById(R.id.tvYapilankm)
        kmyakilan = findViewById(R.id.tvKmdeyakilan)
        hrcm = findViewById(R.id.tvHarcama)
        surum = findViewById(R.id.tvSurum)
        surum.text= "Sürüm : 1.0.17042025"

        sprefs = getSharedPreferences("my_shared_pref", Context.MODE_PRIVATE)
        editor = sprefs.edit()
        ayarlarioku()

        bthesapla = findViewById(R.id.btHesapla)
        bthesapla.setOnClickListener {
            hesapla()
            ayarlarisakla()
        }

        bttemizle = findViewById(R.id.btTemizle)
        bttemizle.setOnClickListener {
            vkm.setText("0")
            kkm.setText("0")
            ort.setText("0")
            fiyat.setText("0")
            ykm.text = " Yapilan Km : 0"
            kmyakilan.text = "Km'de yakilan : 0 kuruş"
            hrcm.text = "Harcama : 0 lira"
            ayarlarisil()
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    private fun ayarlarioku() {
        //vkm.setText(String.format("%.2f",sprefs.getFloat("VarisKm", 0)));
        vkm.setText(sprefs.getString("VarisKm", "0"))
        kkm.setText(sprefs.getString("KalkisKm", "0"))
        ort.setText(sprefs.getString("Ortalama", "0"))
        fiyat.setText(sprefs.getString("Fiyat", "0"))
        ykm.setText(sprefs.getString("YapilanKm", "Yapilan Km : 0"))
        kmyakilan.setText(sprefs.getString("Kmdeyakilan", "Km'de yakilan : 0 kuruş"))
        hrcm.setText(sprefs.getString("Harcama", "Harcama : 0 lira"))
    }

    private fun ayarlarisakla() {
        // Ayarlar kaydediliyor
        editor.putString("VarisKm", vkm.getText().toString())
        editor.putString("KalkisKm", kkm.getText().toString())
        editor.putString("Ortalama", ort.getText().toString())
        editor.putString("Fiyat", fiyat.getText().toString())
        editor.putString("YapilanKm", ykm.getText().toString())
        editor.putString("Kmdeyakilan", kmyakilan.getText().toString())
        editor.putString("Harcama", hrcm.getText().toString())
        editor.apply()
    }

    private fun ayarlarisil() {
        // Ayarlar siliniyor
        editor.remove("VarisKm")
        editor.remove("KalkisKm")
        editor.remove("Ortalama")
        editor.remove("Fiyat")
        editor.remove("YapilanKm")
        editor.remove("Kmdeyakilan")
        editor.remove("Harcama")
        editor.clear()
        editor.apply()
    }

    private fun hesapla() {
        val hyapilankm: Float
        val hkmdeyakilan: Float

        val hvariskm = vkm.text.toString().toFloat()
        val hkalkiskm = kkm.text.toString().toFloat()
        hyapilankm = hvariskm - hkalkiskm
        ykm.text = "Yapilan Km : " + String.format("%.2f", hyapilankm)
        val hortalama = ort.text.toString().toFloat()
        val hfiyat = fiyat.text.toString().toFloat()
        hkmdeyakilan = hortalama * hfiyat
        kmyakilan.text ="Km'de yakilan : " + String.format("%.2f", hkmdeyakilan) + " kuruş"
        val hharcama = hyapilankm * (hkmdeyakilan / 100)
        hrcm.text = "Harcama : " + String.format("%.2f", hharcama) + " lira"
    }
}